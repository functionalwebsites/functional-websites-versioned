// Global scripts
